import { BrowserRouter as Router, Link, Route, Switch } from "react-router-dom";
import AddEmployee from "./component/employee/AddEmployee";
import EditEmployee from "./component/employee/EditEmployee";
import ListEmployee from "./component/employee/ListEmployee";

function App() {
  return (
    <div className="App">
      <Router>
        <div className="row container p-3 rounded border m-3 mx-auto">
          <li className="nav-item col-3 m-1">
            <Link className=" btn btn-success" to={"/addEmployee"}>
              AddEmployee
            </Link>
          </li>
          <li className="nav-item col-3 m-1 ">
            <Link className=" btn btn-success" to={"/editEmployee"}>
              EditEmployee
            </Link>
          </li>
          <li className="nav-item  col-3 m-1">
            <Link className=" btn btn-success" to={"/listEmployee"}>
              ListEmployee
            </Link>
          </li>
        </div>
        <Switch>
          <Route exact path="/addEmployee" component={AddEmployee}></Route>
          <Route exact path="/editEmployee" component={EditEmployee}></Route>
          <Route exact path="/listEmployee" component={ListEmployee}></Route>
        </Switch>
      </Router>
    </div>
  );
}

export default App;
