import PropTypes from "prop-types";
import React, { useState } from "react";
import axios from "axios";
import classnames from "classnames";

const AddEmployee = (props) => {
  const [employee, setEmployee] = useState({
    employeeId: "",
    firstName: "",
    lastName: "",
    email: "",
    address: "",
    phoneNumber: "",
    qualification: "",
  });

  const [showLoad, setShowLoad] = useState(false);

  const [errors, setErrors] = useState({});

  const {
    employeeId,
    firstName,
    lastName,
    email,
    address,
    phoneNumber,
    qualification,
  } = employee;

  const apiURL = "http://localhost:8080/employeess";

  const onChange = (e) => {
    setEmployee({ ...employee, [e.target.name]: e.target.value });
  };
  const onSubmit = (e) => {
    e.preventDefault();
    console.log(JSON.stringify(employee));
    axios
      .post(apiURL, employee)
      .then((res) => props.history.push("/EmployeeList"));
  };

  return (
    <div className="register">
      <div className="container">
        <div className="row">
          <div className="col-md-8 m-auto">
            <form onSubmit={onSubmit}>
              <div className="form-group">
                <input
                  type="employeeId"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.employeeId,
                  })}
                  placeholder="employeeId"
                  name="employeeId"
                  value={employeeId}
                  onChange={onChange}
                />
                {errors.employeeId && (
                  <div className="d-block invalid-feedback">
                    {errors.employeeId}
                  </div>
                )}
              </div>

              <div className="form-group">
                <input
                  type="firstName"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.firstName,
                  })}
                  placeholder="firstName"
                  name="firstName"
                  value={firstName}
                  onChange={onChange}
                />
                {errors.firstName && (
                  <div className="d-block invalid-feedback">
                    {errors.firstName}
                  </div>
                )}
              </div>

              <div className="form-group">
                <input
                  type="lastName"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.lastName,
                  })}
                  placeholder="lastName"
                  name="lastName"
                  value={lastName}
                  onChange={onChange}
                />
                {errors.lastName && (
                  <div className="d-block invalid-feedback">
                    {errors.lastName}
                  </div>
                )}
              </div>

              <div className="form-group">
                <input
                  type="email"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.email,
                  })}
                  placeholder="Email Address"
                  name="email"
                  value={email}
                  onChange={onChange}
                />

                {errors.email && (
                  <div className="d-block invalid-feedback">{errors.email}</div>
                )}
              </div>
              <div className="form-group">
                <input
                  type="address"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.address,
                  })}
                  placeholder="address"
                  name="address"
                  value={address}
                  onChange={onChange}
                />
                {errors.address && (
                  <div className="d-block invalid-feedback">
                    {errors.address}
                  </div>
                )}
              </div>
              <div className="form-group">
                <input
                  type="phoneNumber"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.phoneNumber,
                  })}
                  placeholder="phoneNumber"
                  name="phoneNumber"
                  value={phoneNumber}
                  onChange={onChange}
                />
                {errors.phoneNumber && (
                  <div className="d-block invalid-feedback">
                    {errors.phoneNumber}
                  </div>
                )}
              </div>

              <div className="form-group">
                <input
                  type="qualification"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.qualification,
                  })}
                  placeholder="qualification"
                  name="qualification"
                  value={qualification}
                  onChange={onChange}
                />
                {errors.qualification && (
                  <div className="d-block invalid-feedback">
                    {errors.qualification}
                  </div>
                )}
              </div>
              <input type="submit" className="btn btn-info btn-block mt-4" />
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

AddEmployee.propTypes = {};

export default AddEmployee;
