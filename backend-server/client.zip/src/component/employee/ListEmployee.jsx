import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import axios from "axios";

import { CardHeader, Table } from "reactstrap";

const ListEmployee = (props) => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const GetData = async () => {
      const result = await axios("http://localhost:8080/employeess/all");
      console.log(result.data);
      setData(result.data);
    };
    GetData();
  }, []);

  const deleteEmployee = (id) => {
    axios.delete("http://localhost:8080/employeess/" + id).then((result) => {
      props.history.push("/");
    });
  };

  const editEmployee = (id) => {
    props.history.push({
      pathname: "/edit/" + id,
    });
  };

  return (
    <div className="animated fadeIn">
      <CardHeader>
        <i className="fa fa-align-justify"></i> EmployeeList
      </CardHeader>
      <Table hover board stripped responsive size="sm">
        <thead>
          <tr>
            <th>EmployeeId </th>
            <th>FirstName </th>
            <th>LastName </th>
            <th>Email </th>
            <th>Address </th>
            <th>PhoneNumber </th>
            <th>Qualification</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, idx) => {
            return (
              <tr>
                <td>{item.employeeId}</td>
                <td>{item.firstName}</td>
                <td>{item.lastName}</td>
                <td>{item.email}</td>
                <td>{item.address}</td>
                <td>{item.phoneNumber}</td>
                <td>{item.qualification}</td>

                <td>
                  <div class="btn-group">
                    <button
                      className="btn btn-warning"
                      onClick={() => {
                        editEmployee(item.employeeId);
                      }}
                    >
                      Edit
                    </button>

                    <button
                      className="btn btn-warning"
                      onClick={() => {
                        deleteEmployee(item.employeeId);
                      }}
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </Table>
    </div>
  );
};

ListEmployee.propTypes = {};

export default ListEmployee;
