import React, { useEffect, useState } from "react";
import axios from "axios";
import classnames from "classnames";
import { Button, Col } from "reactstrap";

const EditEmployee = (props) => {
  const [employee, setEmployee] = useState({
    employeeId: "",
    firstName: "",
    lastName: "",
    email: "",
    address: "",
    phoneNumber: "",
    qualification: "",
  });

  const [errors, setErrors] = useState({});

  const Url =
    "http://localhost:8080/employeess" + props.match.params.employeeId;

  useEffect(() => {
    const GetData = async () => {
      const result = await axios.get(Url);
      setEmployee(result.data);
    };

    GetData();
  }, []);

  const UpdateEmployee = async (e) => {
    e.preventDefault();

    const data = {
      employeeId: employee.employeeId,
      firstName: employee.firstName,
      lastName: employee.lastName,
      email: employee.email,
      address: employee.address,
      phoneNumber: employee.phoneNumber,
      qualification: employee.qualification,
    };
    console.log(JSON.stringify(data));
    console.log("check 1");
    await axios
      .put("http://localhost:8080/employeess/" + employee.employeeId, data)
      .then((result) => {
        props.history.push("/EmployeeList");
      });
  };

  const onChange = (e) => {
    e.persist();
    setEmployee({ ...employee, [e.target.name]: e.target.value });
    console.log(JSON.stringify(employee));
  };

  return (
    <div className="register">
      <div className="container">
        <div className="row">
          <div className="col-md-8 m-auto">
            <form onSubmit={UpdateEmployee}>
              <div className="form-group">
                <input
                  type="employeeId"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.employeeId,
                  })}
                  placeholder="employeeId"
                  name="employeeId"
                  value={employee.employeeId}
                  onChange={onChange}
                />
                {errors.employeeId && (
                  <div className="d-block invalid-feedback">
                    {errors.employeeId}
                  </div>
                )}
              </div>

              <div className="form-group">
                <input
                  type="firstName"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.firstName,
                  })}
                  placeholder="firstName"
                  name="firstName"
                  value={employee.firstName}
                  onChange={onChange}
                />
                {errors.firstName && (
                  <div className="d-block invalid-feedback">
                    {errors.firstName}
                  </div>
                )}
              </div>

              <div className="form-group">
                <input
                  type="lastName"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.lastName,
                  })}
                  placeholder="lastName"
                  name="lastName"
                  value={employee.lastName}
                  onChange={onChange}
                />
                {errors.lastName && (
                  <div className="d-block invalid-feedback">
                    {errors.lastName}
                  </div>
                )}
              </div>

              <div className="form-group">
                <input
                  type="email"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.email,
                  })}
                  placeholder="Email Address"
                  name="email"
                  value={employee.email}
                  onChange={onChange}
                />

                {errors.email && (
                  <div className="d-block invalid-feedback">{errors.email}</div>
                )}
              </div>
              <div className="form-group">
                <input
                  type="address"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.address,
                  })}
                  placeholder="address"
                  name="address"
                  value={employee.address}
                  onChange={onChange}
                />
                {errors.address && (
                  <div className="d-block invalid-feedback">
                    {errors.address}
                  </div>
                )}
              </div>
              <div className="form-group">
                <input
                  type="phoneNumber"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.phoneNumber,
                  })}
                  placeholder="phoneNumber"
                  name="phoneNumber"
                  value={employee.phoneNumber}
                  onChange={onChange}
                />
                {errors.phoneNumber && (
                  <div className="d-block invalid-feedback">
                    {errors.phoneNumber}
                  </div>
                )}
              </div>

              <div className="form-group">
                <input
                  type="qualification"
                  className={classnames("form-control form-control-lg", {
                    "is-invalid": errors.qualification,
                  })}
                  placeholder="qualification"
                  name="qualification"
                  value={employee.qualification}
                  onChange={onChange}
                />
                {errors.qualification && (
                  <div className="d-block invalid-feedback">
                    {errors.qualification}
                  </div>
                )}
              </div>
              <Col xs="12" sm="6">
                <Button type="submit" className="btn btn-info mb-1" block>
                  <span>Save</span>
                </Button>
              </Col>

              <Col xs="12" sm="6">
                <Button type="submit" className="btn btn-info mb-1" block>
                  <span>Cancel</span>
                </Button>
              </Col>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

EditEmployee.propTypes = {};

export default EditEmployee;
